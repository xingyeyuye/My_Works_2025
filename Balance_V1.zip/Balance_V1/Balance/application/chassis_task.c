#include "chassis_task.h"
#include "INS_task.h"
#include "struct_typedef.h"
#include "gimbal_task.h"
#include "remote_control.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"


chassis_control_t chassis_control;
//底盘速度PID
const fp32 chassis_speed_pid_constants[3]={Motor_SPEED_PID_KP,Motor_SPEED_PID_KI,Motor_SPEED_PID_KD};
//底盘陀螺仪角度PID
const fp32 chassis_absolute_angle_pid_constants[3]={CHASSIS_ABSOLUTE_ANGLE_PID_KP,CHASSIS_ABSOLUTE_ANGLE_PID_KI,CHASSIS_ABSOLUTE_ANGLE_PID_KD};
//底盘陀螺仪角速度PID
const fp32 chassis_absolute_gyro_pid_constants[3]={CHASSIS_GYRO_ABSOLUTE_PID_KP,CHASSIS_GYRO_ABSOLUTE_PID_KI,CHASSIS_GYRO_ABSOLUTE_PID_KD};

int target1,target2,actual1,actual2,out1,out2;

fp32 vx_set;
fp32 vy_set;
fp32 wz_set=0.0f;
fp32 wheel_speed[4]={0};
uint8_t i=0;
fp32 left_target_value;
fp32 right_target_value;
fp32 balance_target_value;
//chassis整车陀螺仪角速度
fp32 chassis_target_BMI088_gyro;
fp32 chassis_last_target_BMI088_gyro;
fp32 chassis_set_BMI088_gyro;
fp32 chassis_last_set_BMI088_gyro;
fp32 chassis_delta_BMI088_gyro;
fp32 chassis_current_BMI088_gyro[3];
//chassis左轮陀螺仪角速度
fp32 chassis_left_target_BMI088_gyro;
fp32 chassis_left_last_target_BMI088_gyro;
fp32 chassis_left_set_BMI088_gyro;
fp32 chassis_left_last_set_BMI088_gyro;
fp32 chassis_left_delta_BMI088_gyro;
fp32 chassis_left_current_BMI088_gyro[3];
//chassis右轮陀螺仪角速度
fp32 chassis_right_target_BMI088_gyro;
fp32 chassis_right_last_target_BMI088_gyro;
fp32 chassis_right_set_BMI088_gyro;
fp32 chassis_right_last_set_BMI088_gyro;
fp32 chassis_right_delta_BMI088_gyro;
fp32 chassis_right_current_BMI088_gyro[3];

//chassis整车陀螺仪角度
fp32 chassis_target_INS_angle;
fp32 chassis_set_INS_angle;
fp32 chassis_last_set_INS_angle;
fp32 chassis_delta_INS_angle;
fp32 chassis_current_INS_angle[3];
fp32 chassis_now_INS_angle;

//chassis左轮陀螺仪角度
fp32 chassis_left_target_INS_angle;
fp32 chassis_left_set_INS_angle;
fp32 chassis_left_last_set_INS_angle;
fp32 chassis_left_delta_INS_angle;
fp32 chassis_left_current_INS_angle[3];
fp32 chassis_left_now_INS_angle;

//chassis右轮陀螺仪角度
fp32 chassis_right_target_INS_angle;
fp32 chassis_right_set_INS_angle;
fp32 chassis_right_last_set_INS_angle;
fp32 chassis_right_delta_INS_angle;
fp32 chassis_right_current_INS_angle[3];
fp32 chassis_right_now_INS_angle;

fp32 Vertical_Kp=800;
fp32 Vertical_Kd=2000;

//映射函数，将编码器的值（0~8191）转换为弧度制的角度值（-pi~pi）
double msp(double x, double in_min, double in_max, double out_min, double out_max);
//绝对值函数
fp32 my_fabs(fp32 x);
// 一阶低通滤波器更新函数
float lowPassFilter(float alpha, float prevOutput, float input);
//直立环
int Vertical(fp32 Med,fp32 Angle,fp32 gyro);

void Chassis_task(void const *pvParameters)
{
	//获取遥控器数据指针
	chassis_control.chassis_rc_ctrl = get_remote_control_point();
	//获取电机数据
	chassis_control.chassis_left_motor.chassis_motor_measure = get_chassis_motor_measure_point(0);
	chassis_control.chassis_right_motor.chassis_motor_measure = get_chassis_motor_measure_point(1);
	//获取陀螺仪角速度
	chassis_control.chassis_INT_gyro_point=get_gyro_data_point();
	//获取陀螺仪角度
	chassis_control.chassis_INT_angle_point=get_INS_angle_point();
	
	//底盘速度环初始化
	PID_init(&chassis_control.chassis_left_motor.chassis_gyro_pid,PID_POSITION,chassis_speed_pid_constants,Motor_SPEED_PID_OUT_MAX,Motor_SPEED_PIF_IOUT_MAX);
	PID_init(&chassis_control.chassis_right_motor.chassis_gyro_pid,PID_POSITION,chassis_speed_pid_constants,Motor_SPEED_PID_OUT_MAX,Motor_SPEED_PIF_IOUT_MAX);
	//底盘陀螺仪角速度环初始化
	PID_init(&chassis_control.chassis_left_motor.chassis_BMI088_gyro_pid,PID_POSITION,chassis_absolute_gyro_pid_constants,CHASSIS_GYRO_ABSOLUTE_PID_MAX_OUT,CHASSIS_GYRO_ABSOLUTE_PID_MAX_IOUT);
	PID_init(&chassis_control.chassis_right_motor.chassis_BMI088_gyro_pid,PID_POSITION,chassis_absolute_gyro_pid_constants,CHASSIS_GYRO_ABSOLUTE_PID_MAX_OUT,CHASSIS_GYRO_ABSOLUTE_PID_MAX_IOUT);
	//底盘陀螺仪角度环初始化
	PID_init(&chassis_control.chassis_left_motor.chassis_absolute_angle_pid,PID_POSITION,chassis_absolute_angle_pid_constants,CHASSIS_ABSOLUTE_ANGLE_PID_MAX_OUT,CHASSIS_ABSOLUTE_ANGLE_PID_MAX_IOUT);
	PID_init(&chassis_control.chassis_right_motor.chassis_absolute_angle_pid,PID_POSITION,chassis_absolute_angle_pid_constants,CHASSIS_ABSOLUTE_ANGLE_PID_MAX_OUT,CHASSIS_ABSOLUTE_ANGLE_PID_MAX_IOUT);
	
	while(1)
	{
		//获取底盘角度当前值
		chassis_current_INS_angle[0]=*(chassis_control.chassis_INT_angle_point+INS_YAW_ADDRESS_OFFSET)*180/PI;
		if(chassis_current_INS_angle[0]<0)
		{
			chassis_current_INS_angle[0]=msp(chassis_current_INS_angle[0],-180,-1,180,359);//陀螺仪反馈角度一圈是0~180~-180~0，此行代码将-180~-1映射到181~360.
		}
		chassis_current_INS_angle[1]=*(chassis_control.chassis_INT_angle_point+INS_PITCH_ADDRESS_OFFSET)*180/PI;//-1.1f
		chassis_current_INS_angle[2]=*(chassis_control.chassis_INT_angle_point+INS_ROLL_ADDRESS_OFFSET)*180/PI;
		//获取底盘角速度当前值
		chassis_current_BMI088_gyro[0]=*(chassis_control.chassis_INT_gyro_point+INS_GYRO_X_ADDRESS_OFFSET);
		chassis_current_BMI088_gyro[1]=*(chassis_control.chassis_INT_gyro_point+INS_GYRO_Y_ADDRESS_OFFSET);//直立
		chassis_current_BMI088_gyro[2]=*(chassis_control.chassis_INT_gyro_point+INS_GYRO_Z_ADDRESS_OFFSET);//chassis轴角速度
		//获取底盘角速度当前值
		
		
		vx_set = chassis_control.chassis_rc_ctrl->rc.ch[1]*20.f;
		vy_set = chassis_control.chassis_rc_ctrl->rc.ch[0]*20.f;
		
		//发送串口显示滤波
		target1=0;
		actual1=(chassis_control.chassis_left_motor.chassis_motor_measure->speed_rpm+chassis_control.chassis_right_motor.chassis_motor_measure->speed_rpm)/2;
		out1=chassis_target_BMI088_gyro;

		if(chassis_control.chassis_rc_ctrl->rc.s[0]==3)
		{
//			//速度环
			chassis_left_target_BMI088_gyro=chassis_control.chassis_rc_ctrl->rc.ch[1];
//			chassis_right_target_BMI088_gyro=0.0f;
////			PID_calc(&chassis_control.chassis_left_motor.chassis_BMI088_gyro_pid,chassis_current_BMI088_gyro[1],chassis_left_target_BMI088_gyro);
////			PID_calc(&chassis_control.chassis_right_motor.chassis_BMI088_gyro_pid,chassis_current_BMI088_gyro[1],chassis_right_target_BMI088_gyro);
//			
			PID_calc(&chassis_control.chassis_left_motor.chassis_gyro_pid,(chassis_control.chassis_left_motor.chassis_motor_measure->speed_rpm+chassis_control.chassis_right_motor.chassis_motor_measure->speed_rpm)/2,chassis_left_target_BMI088_gyro);
//			PID_calc(&chassis_control.chassis_right_motor.chassis_gyro_pid,(chassis_control.chassis_left_motor.chassis_motor_measure->speed_rpm+chassis_control.chassis_right_motor.chassis_motor_measure->speed_rpm)/2,chassis_right_target_BMI088_gyro);
//			//直立环
//			chassis_left_target_INS_angle=chassis_control.chassis_left_motor.chassis_gyro_pid.out;
////			chassis_right_target_INS_angle=chassis_control.chassis_right_motor.chassis_gyro_pid.out;	
////			PID_calc(&chassis_control.chassis_left_motor.chassis_absolute_angle_pid,chassis_current_INS_angle[1],-1);
////			PID_calc(&chassis_control.chassis_right_motor.chassis_absolute_angle_pid,chassis_current_INS_angle[1],-1);
//			PID_calc(&chassis_control.chassis_left_motor.chassis_absolute_angle_pid,chassis_current_INS_angle[1],chassis_left_target_INS_angle);
//			left_target_value=chassis_control.chassis_left_motor.chassis_absolute_angle_pid.out-100*(0-chassis_current_BMI088_gyro[2]);
////			PID_calc(&chassis_control.chassis_right_motor.chassis_absolute_angle_pid,chassis_current_INS_angle[1],chassis_right_target_INS_angle);
//			right_target_value=chassis_control.chassis_left_motor.chassis_absolute_angle_pid.out+100*(0-chassis_current_BMI088_gyro[2]);
			balance_target_value= Vertical(-1,chassis_current_INS_angle[1],chassis_current_BMI088_gyro[1]);
			left_target_value=-chassis_control.chassis_left_motor.chassis_gyro_pid.out+balance_target_value+800*(chassis_control.chassis_rc_ctrl->rc.ch[0]/100-chassis_current_BMI088_gyro[2]);
			right_target_value=-chassis_control.chassis_left_motor.chassis_gyro_pid.out+balance_target_value-800*(chassis_control.chassis_rc_ctrl->rc.ch[0]/100-chassis_current_BMI088_gyro[2]);
			CAN_cmd_chassis(-left_target_value,right_target_value,0,0);
			
		}
		else if(chassis_control.chassis_rc_ctrl->rc.s[0]==2)
		{
			PID_clear(&chassis_control.chassis_left_motor.chassis_BMI088_gyro_pid);
			PID_clear(&chassis_control.chassis_right_motor.chassis_BMI088_gyro_pid);
			PID_clear(&chassis_control.chassis_left_motor.chassis_absolute_angle_pid);
			PID_clear(&chassis_control.chassis_right_motor.chassis_absolute_angle_pid);
			PID_clear(&chassis_control.chassis_right_motor.chassis_gyro_pid);
			PID_clear(&chassis_control.chassis_right_motor.chassis_gyro_pid);
			CAN_cmd_chassis(0,0,0,0);
		}
		
		osDelay(10); 
	}
}



//映射函数，将编码器的值（0~8191）转换为弧度制的角度值（-pi~pi）
double msp(double x, double in_min, double in_max, double out_min, double out_max)
{
	return (x-in_min)*(out_max-out_min)/(in_max-in_min)+out_min;
}

// 一阶低通滤波器更新函数
float lowPassFilter(float alpha, float prevOutput, float input) {
    return alpha * input + (1.0f - alpha) * prevOutput;
}

fp32 my_fabs(fp32 x) {
    return (x < 0) ? -x : x;
}
//直立环
int Vertical(fp32 Med,fp32 Angle,fp32 gyro)
{
	int value;
	
	value=Vertical_Kp*(Angle-Med)+Vertical_Kd*(gyro-0);
	return value;
}
