#ifndef CHASSIS_TASK_H
#define CHASSIS_TASK_H

#include "remote_control.h"
#include "CAN_receive.h"
#include "pid.h"

//����ǰ�����ҿ��ư���
#define CHASSIS_FRONT_KEY KEY_PRESSED_OFFSET_W
#define CHASSIS_BACK_KEY KEY_PRESSED_OFFSET_S
#define CHASSIS_LEFT_KEY KEY_PRESSED_OFFSET_A
#define CHASSIS_RIGHT_KEY KEY_PRESSED_OFFSET_D

#define Motor_SPEED_PID_KP -8.0f
#define Motor_SPEED_PID_KI -0.4f
#define Motor_SPEED_PID_KD 0.0f
#define Motor_SPEED_PID_OUT_MAX 16000
#define Motor_SPEED_PIF_IOUT_MAX 1200

//yaw �ǶȻ� �Ƕ��������� PID�����Լ� PID���������������
#define CHASSIS_ABSOLUTE_ANGLE_PID_KP        300.0f  
#define CHASSIS_ABSOLUTE_ANGLE_PID_KI        0.0f  
#define CHASSIS_ABSOLUTE_ANGLE_PID_KD        5.00f	
#define CHASSIS_ABSOLUTE_ANGLE_PID_MAX_OUT   25000.0f
#define CHASSIS_ABSOLUTE_ANGLE_PID_MAX_IOUT  8000.0f

//yaw ���ٶȻ� �Ƕ��������� PID�����Լ� PID���������������
#define CHASSIS_GYRO_ABSOLUTE_PID_KP        15.0f  
#define CHASSIS_GYRO_ABSOLUTE_PID_KI        0.5f  
#define CHASSIS_GYRO_ABSOLUTE_PID_KD        0.00f	
#define CHASSIS_GYRO_ABSOLUTE_PID_MAX_OUT   90.0f
#define CHASSIS_GYRO_ABSOLUTE_PID_MAX_IOUT  10.0f	

extern int target1,target2,actual1,actual2,out1,out2;
typedef struct
{
    const motor_measure_t *chassis_motor_measure;
//    gimbal_PID_t gimbal_motor_absolute_angle_pid;
	pid_type_def chassis_absolute_angle_pid;
	pid_type_def chassis_INS_speed_pid;
    //gimbal_PID_t gimbal_motor_relative_angle_pid;
    pid_type_def chassis_relative_angle_pid;
    pid_type_def chassis_gyro_pid;
	pid_type_def chassis_BMI088_gyro_pid;
	pid_type_def chassis_BMI088_speed_pid;
    uint16_t offset_ecd;
    fp32 max_relative_angle; //rad
    fp32 min_relative_angle; //rad

    fp32 relative_angle;     //rad
    fp32 relative_angle_set; //rad
    fp32 absolute_angle;     //rad
    fp32 absolute_angle_set; //rad
    fp32 motor_gyro;         //rad/s
    fp32 motor_gyro_set;
    fp32 motor_speed;
    fp32 raw_cmd_current;
    fp32 current_set;
    int16_t given_current;

} chassis_motor_t;


typedef struct
{
    const RC_ctrl_t *chassis_rc_ctrl;
    const fp32 *chassis_INT_angle_point;
    const fp32 *chassis_INT_gyro_point;
    chassis_motor_t chassis_left_motor;
	chassis_motor_t chassis_right_motor;

} chassis_control_t;

#endif
