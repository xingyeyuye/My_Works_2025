#include "chassis_task.h"
#include "INS_task.h"
#include "struct_typedef.h"
#include "gimbal_task.h"
#include "remote_control.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"
#include "user_lib.h"

chassis_control_t chassis_control;
//底盘速度PID
const fp32 chassis_speed_pid_constants[3]={Motor_SPEED_PID_KP,Motor_SPEED_PID_KI,Motor_SPEED_PID_KD};
//底盘陀螺仪角度PID
const fp32 chassis_absolute_angle_pid_constants[3]={CHASSIS_ABSOLUTE_ANGLE_PID_KP,CHASSIS_ABSOLUTE_ANGLE_PID_KI,CHASSIS_ABSOLUTE_ANGLE_PID_KD};
//底盘陀螺仪角速度PID
const fp32 chassis_absolute_gyro_pid_constants[3]={CHASSIS_GYRO_ABSOLUTE_PID_KP,CHASSIS_GYRO_ABSOLUTE_PID_KI,CHASSIS_GYRO_ABSOLUTE_PID_KD};

int target1,target2,actual1,actual2,out1,out2;

fp32 wz_set=0.0f;
fp32 wheel_speed[4]={0};
uint8_t i=0;
fp32 left_target_value;
fp32 right_target_value;
fp32 balance_target_value;
//chassis整车陀螺仪角速度
fp32 chassis_target_BMI088_gyro;
fp32 chassis_last_target_BMI088_gyro;
fp32 chassis_set_BMI088_gyro;
fp32 chassis_last_set_BMI088_gyro;
fp32 chassis_delta_BMI088_gyro;
fp32 chassis_current_BMI088_gyro[3];

//chassis整车陀螺仪角度
fp32 chassis_target_INS_angle;
fp32 chassis_set_INS_angle;
fp32 chassis_last_set_INS_angle;
fp32 chassis_delta_INS_angle;
fp32 chassis_current_INS_angle[3];
fp32 chassis_now_INS_angle;

//映射函数，将编码器的值（0~8191）转换为弧度制的角度值（-pi~pi）
double msp(double x, double in_min, double in_max, double out_min, double out_max);
//绝对值函数
fp32 my_fabs(fp32 x);
// 一阶低通滤波器更新函数
float lowPassFilter(float alpha, float prevOutput, float input);
//最大值,最小值限幅函数
void mySaturate(fp32 *in,fp32 min,fp32 max);

//float lqr_k[2][4]={  {-0.1581f,-1.6792f,-7.1582f,-1.4466f}  ,
// {-0.1581f,-1.6792f,-7.1582f,-1.4466f}  };
float lqr_k[2][4]={     {-0.0707f,-2.2628f,-6.1002f,-0.7985f} ,
    {-0.0707f,-2.2628f,-6.1002f,-0.7985f}};

void Chassis_task(void const *pvParameters)
{
	//获取遥控器数据指针
	chassis_control.chassis_rc_ctrl = get_remote_control_point();
	//获取电机数据
	chassis_control.chassis_left_motor.chassis_motor_measure = get_chassis_motor_measure_point(0);
	chassis_control.chassis_right_motor.chassis_motor_measure = get_chassis_motor_measure_point(1);
	//获取陀螺仪角速度
	chassis_control.chassis_INT_gyro_point=get_gyro_data_point();
	//获取陀螺仪角度
	chassis_control.chassis_INT_angle_point=get_INS_angle_point();
	
	
	while(1)
	{
		//底盘测量数据更新，包括电机旋转速度，欧拉角度，机器人速度
			//获取底盘角度当前值
			chassis_current_INS_angle[0]=*(chassis_control.chassis_INT_angle_point+INS_YAW_ADDRESS_OFFSET)*180/PI;
			if(chassis_current_INS_angle[0]<0)
			{
				chassis_current_INS_angle[0]=msp(chassis_current_INS_angle[0],-180,-1,180,359);//陀螺仪反馈角度一圈是0~180~-180~0，此行代码将-180~-1映射到181~360.
			}
//			chassis_current_INS_angle[1]=*(chassis_control.chassis_INT_angle_point+INS_PITCH_ADDRESS_OFFSET)*180/PI;//-1.1f
			//获取pitch角度
			chassis_current_INS_angle[1]=rad_format(*(chassis_control.chassis_INT_angle_point+INS_PITCH_ADDRESS_OFFSET));//-1.1f
			chassis_current_INS_angle[2]=*(chassis_control.chassis_INT_angle_point+INS_ROLL_ADDRESS_OFFSET)*180/PI;
			//获取底盘角速度当前值
			chassis_current_BMI088_gyro[0]=*(chassis_control.chassis_INT_gyro_point+INS_GYRO_X_ADDRESS_OFFSET);
			chassis_current_BMI088_gyro[1]=*(chassis_control.chassis_INT_gyro_point+INS_GYRO_Y_ADDRESS_OFFSET);//直立
			chassis_current_BMI088_gyro[2]=*(chassis_control.chassis_INT_gyro_point+INS_GYRO_Z_ADDRESS_OFFSET);
			//获取底盘角速度当前值
			
			
			chassis_control.v_set = chassis_control.chassis_rc_ctrl->rc.ch[1]*CHASSIS_VX_RC_SEN;//速度设置
			chassis_control.x_set =0;
			//计算各电机的轮轴位移速度
			chassis_control.chassis_left_motor.motor_speed=CHASSIS_MOTOR_RPM_TO_VECTOR_SEN*chassis_control.chassis_left_motor.chassis_motor_measure->speed_rpm;
			chassis_control.chassis_right_motor.motor_speed=CHASSIS_MOTOR_RPM_TO_VECTOR_SEN*chassis_control.chassis_right_motor.chassis_motor_measure->speed_rpm;
			//计算底盘速度
			chassis_control.v=(chassis_control.chassis_left_motor.motor_speed-chassis_control.chassis_right_motor.motor_speed)/2.0f;
			//更新电机转矩
			chassis_control.chassis_left_motor.torque=CHASSIS_MOTOR_CURRENT_TO_TORQUE_SEN*chassis_control.chassis_left_motor.chassis_motor_measure->given_current;
			chassis_control.chassis_right_motor.torque=CHASSIS_MOTOR_CURRENT_TO_TORQUE_SEN*chassis_control.chassis_right_motor.chassis_motor_measure->given_current;
			
		if(chassis_control.chassis_rc_ctrl->rc.s[0]==3)
		{
			 chassis_control.chassis_left_motor.torque_set =-(lqr_k[0][1]*(chassis_control.v-chassis_control.v_set)
																				+lqr_k[0][2]*(-(0.0174533f)-chassis_current_INS_angle[1])//0.05rad是机械中值
																				+lqr_k[0][3]*(0-chassis_current_BMI088_gyro[1]));//角速度目标值为0
		
			chassis_control.chassis_right_motor.torque_set =lqr_k[1][1]*(chassis_control.v-chassis_control.v_set)
																				+lqr_k[1][2]*(0-chassis_current_INS_angle[1])//0.05rad是机械中值
																				+lqr_k[1][3]*(0-chassis_current_BMI088_gyro[1]);//角速度目标值为0
		
//			chassis_control.chassis_left_motor.torque_set=0.0f-chassis_control.chassis_left_motor.torque_set;
		
//			turn_T= Turn(chassis_move.total_yaw,INS.Gyro[2]);
//			
//			chassis_move.wheel_motor[0].wheel_T=chassis_move.wheel_motor[0].wheel_T-turn_T;
//			chassis_move.wheel_motor[1].wheel_T=chassis_move.wheel_motor[1].wheel_T-turn_T;
			
			chassis_control.chassis_left_motor.current_set=chassis_control.chassis_left_motor.torque_set/CHASSIS_MOTOR_CURRENT_TO_TORQUE_SEN;
			chassis_control.chassis_right_motor.current_set=chassis_control.chassis_right_motor.torque_set/CHASSIS_MOTOR_CURRENT_TO_TORQUE_SEN;
//			mySaturate(&chassis_control.chassis_left_motor.current_set,-16384,16384);
//			mySaturate(&chassis_control.chassis_right_motor.current_set,-16384,16384);
			
			CAN_cmd_chassis(chassis_control.chassis_left_motor.current_set,chassis_control.chassis_right_motor.current_set,0,0);
		}
		else if(chassis_control.chassis_rc_ctrl->rc.s[0]==2)
		{
			CAN_cmd_chassis(0,0,0,0);
		}
		
		//发送串口显示滤波
//		target1=0;
//		actual1=(chassis_control.chassis_left_motor.chassis_motor_measure->speed_rpm+chassis_control.chassis_right_motor.chassis_motor_measure->speed_rpm)/2;
//		out1=chassis_target_BMI088_gyro;
		
		osDelay(10); 
	}
}



//映射函数，将编码器的值（0~8191）转换为弧度制的角度值（-pi~pi）
double msp(double x, double in_min, double in_max, double out_min, double out_max)
{
	return (x-in_min)*(out_max-out_min)/(in_max-in_min)+out_min;
}

// 一阶低通滤波器更新函数
float lowPassFilter(float alpha, float prevOutput, float input) {
    return alpha * input + (1.0f - alpha) * prevOutput;
}

fp32 my_fabs(fp32 x) {
    return (x < 0) ? -x : x;
}

//最大值,最小值限幅函数
void mySaturate(fp32 *in,fp32 min,fp32 max)
{
  if(*in < min)
  {
    *in = min;
  }
  else if(*in > max)
  {
    *in = max;
  }
}
