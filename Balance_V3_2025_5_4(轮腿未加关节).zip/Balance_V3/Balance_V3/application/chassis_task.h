#ifndef CHASSIS_TASK_H
#define CHASSIS_TASK_H

#include "remote_control.h"
#include "CAN_receive.h"
#include "pid.h"
//m3508减速比约为19:1

// 角速度转换 ω=(rpm×2π)/60(rad/s) ,线速度计算 v=ω×r(轮子半径m)=51.287×0.11≈5.64m/s
//LK9025转子转速(rpm)转化成底盘速度(m/s)的比例,k= 2πr/60
// r 为轮子半径（单位：米）,2π/60 是将转速从转每分钟（rpm）转换为弧度每秒（rad/s）的系数,r=0.100m
#define CHASSIS_MOTOR_RPM_TO_VECTOR_SEN 0.01047f

//LK9025_V2(16T)扭矩常数为 0.32 N.m/A
#define iTRQUE_TO_TORQUE_SEN 0.32f

//rocker value (max 660) change to vertial speed (m/s) 
//遥控器前进摇杆（max 660）转化成车体前进速度（m/s）的比例
#define CHASSIS_VX_RC_SEN 0.012f

//rocker value change to rotation target angle
//遥控器的yaw遥杆（max 660）转化成车体旋转目标角度的比例
#define CHASSIS_ANGLE_Z_RC_SEN 0.000003f

//底盘前后左右控制按键
#define CHASSIS_FRONT_KEY KEY_PRESSED_OFFSET_W
#define CHASSIS_BACK_KEY KEY_PRESSED_OFFSET_S
#define CHASSIS_LEFT_KEY KEY_PRESSED_OFFSET_A
#define CHASSIS_RIGHT_KEY KEY_PRESSED_OFFSET_D

#define Motor_SPEED_PID_KP -8.0f
#define Motor_SPEED_PID_KI -0.4f
#define Motor_SPEED_PID_KD 0.0f
#define Motor_SPEED_PID_OUT_MAX 16000
#define Motor_SPEED_PIF_IOUT_MAX 1200

//yaw 角度环 角度由陀螺仪 PID参数以及 PID最大输出，积分输出
#define CHASSIS_ABSOLUTE_ANGLE_PID_KP        0.55f  
#define CHASSIS_ABSOLUTE_ANGLE_PID_KI        0.0000f  
#define CHASSIS_ABSOLUTE_ANGLE_PID_KD        0.05f	
#define CHASSIS_ABSOLUTE_ANGLE_PID_MAX_OUT   10.0f
#define CHASSIS_ABSOLUTE_ANGLE_PID_MAX_IOUT  3.0f

//yaw 角速度环 角度由陀螺仪 PID参数以及 PID最大输出，积分输出
#define CHASSIS_GYRO_ABSOLUTE_PID_KP        1.55f  
#define CHASSIS_GYRO_ABSOLUTE_PID_KI        0.01f  
#define CHASSIS_GYRO_ABSOLUTE_PID_KD        0.00f	
#define CHASSIS_GYRO_ABSOLUTE_PID_MAX_OUT   1.0f
#define CHASSIS_GYRO_ABSOLUTE_PID_MAX_IOUT  0.5f	

extern int target1,target2,actual1,actual2,out1,out2;
typedef struct
{
    const LK9025_motor_measure_t *chassis_motor_measure;
		fp32 torque;          //电机输出力矩
		fp32 torque_set;      //电机输出力矩设定值
//    gimbal_PID_t gimbal_motor_absolute_angle_pid;
	pid_type_def chassis_absolute_angle_pid;
	pid_type_def chassis_INS_speed_pid;
    //gimbal_PID_t gimbal_motor_relative_angle_pid;
    pid_type_def chassis_relative_angle_pid;
    pid_type_def chassis_gyro_pid;
	pid_type_def chassis_BMI088_gyro_pid;
	pid_type_def chassis_BMI088_speed_pid;
    uint16_t offset_ecd;
    fp32 max_relative_angle; //rad
    fp32 min_relative_angle; //rad

    fp32 relative_angle;     //rad
    fp32 relative_angle_set; //rad
    fp32 absolute_angle;     //rad
    fp32 absolute_angle_set; //rad
    fp32 motor_gyro;         //rad/s
    fp32 motor_gyro_set;
    fp32 motor_speed;
    fp32 raw_cmd_current;
    fp32 current_set;
    int16_t given_current;
	
	
} chassis_motor_t;


typedef struct
{
    const RC_ctrl_t *chassis_rc_ctrl;
    const fp32 *chassis_INT_angle_point;
    const fp32 *chassis_INT_gyro_point;
    chassis_motor_t chassis_left_motor;
	chassis_motor_t chassis_right_motor;
	fp32 v_set;//期望速度，单位是m/s
	fp32 x_set;//期望位置，单位是m
	fp32 v;//实际的速度,单位是m/s
	fp32 x;//实际的位移，单位是m

} chassis_control_t;

#endif
