/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       can_receive.c/h
  * @brief      there is CAN interrupt function  to receive motor data,
  *             and CAN send function to send motor current to control motor.
  *             这里是CAN中断接收函数，接收电机数据,CAN发送函数发送电机电流控制电机.
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. done
  *  V1.1.0     Nov-11-2019     RM              1. support hal lib
  *  V1.1.1     01-17-2025      星夜雨夜         2. add LK9025 motor data
  *  V1.1.2     01-28-2025      星夜雨夜         3. add LK9025 send array in CAN_cmd_LK9025()
  *	 V2.0.1     04-17-2025      星夜雨夜         4. add DM8009P motor data
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#include "CAN_receive.h"

#include "cmsis_os.h"

#include "main.h"

extern CAN_HandleTypeDef hcan1;
extern CAN_HandleTypeDef hcan2;

/**
 * @brief  采用浮点数据等比例转换成整数
 * @param  x_int     	要转换的无符号整数
 * @param  x_min      目标浮点数的最小值
 * @param  x_max    	目标浮点数的最大值
 * @param  bits      	无符号整数的位数
 */
float uint_to_float(int x_int, float x_min, float x_max, int bits);

  /**
   * @brief  将浮点数转换为无符号整数
   * @param  x     			要转换的浮点数
   * @param  x_min      浮点数的最小值
   * @param  x_max    	浮点数的最大值
   * @param  bits      	无符号整数的位数
   */
int float_to_uint(float x, float x_min, float x_max, int bits);

//motor data read
#define get_motor_measure(ptr, data)                                    \
    {                                                                   \
        (ptr)->last_ecd = (ptr)->ecd;                                   \
        (ptr)->ecd = (uint16_t)((data)[0] << 8 | (data)[1]);            \
        (ptr)->speed_rpm = (uint16_t)((data)[2] << 8 | (data)[3]);      \
        (ptr)->given_current = (uint16_t)((data)[4] << 8 | (data)[5]);  \
        (ptr)->temperate = (data)[6];                                   \
    }

//LK9025 motor data read
//motor data read
#define get_LK9025_motor_measure(ptr, data)                             \
    {                                                                   \
        (ptr)->last_ecd = (ptr)->ecd;                                   \
        (ptr)->ecd = (uint16_t)((data)[7] << 8 | (data)[6]);            \
        (ptr)->speed_rpm = (uint16_t)((data)[5] << 8 | (data)[4]);      \
        (ptr)->given_current = (uint16_t)((data)[3] << 8 | (data)[2]);  \
        (ptr)->temperate = (data)[1];                                   \
        (ptr)->cmd_data = (data)[0];                                    \
    }

//DM8009P motor data read
//motor data read
void get_DM8009P_motor_measure(DM8009P_motor_measure_t *ptr, uint8_t *data)                             
{                                                                        
    (ptr)->p_int =(((data)[1] << 8) | ((data)[2]));                      
    (ptr)->v_int =(((data)[3] << 4) | ((data)[4]>>4));                   
    (ptr)->t_int =(((data)[4]&0xF << 8) | ((data)[5]));                  
    (ptr)->position =uint_to_float((ptr)->p_int, P_MIN, P_MAX, 16);       
    (ptr)->velocity =uint_to_float((ptr)->v_int, V_MIN, V_MAX, 12);       
    (ptr)->torque =uint_to_float((ptr)->t_int, T_MIN, T_MAX, 12);          
}

/*
motor data,  0:chassis motor1 3508;1:chassis motor3 3508;2:chassis motor3 3508;3:chassis motor4 3508;
4:yaw gimbal motor 6020;5:pitch gimbal motor 6020;6:trigger motor 2006;
电机数据, 0:底盘电机1 3508电机,  1:底盘电机2 3508电机,2:底盘电机3 3508电机,3:底盘电机4 3508电机;
4:yaw云台电机 6020电机; 5:pitch云台电机 6020电机; 6:拨弹电机 2006电机*/
static motor_measure_t motor_chassis[7];

static LK9025_motor_measure_t motor_LK9025[2];//瓴控MF9025电机数据, 0:LK9025电机
static DM8009P_motor_measure_t motor_DM8009P[4];//瓴控MF9025电机数据, 0:LK9025电机

static CAN_TxHeaderTypeDef  gimbal_tx_message;
static uint8_t              gimbal_can_send_data[8];
static CAN_TxHeaderTypeDef  chassis_tx_message;
static uint8_t              chassis_can_send_data[8];

static CAN_TxHeaderTypeDef  LK9025_tx_message;
static uint8_t              LK9025_can_send_data[8];//LK9025发送数组
static CAN_TxHeaderTypeDef  DM8009P_tx_message;
static uint8_t              DM8009P_can_send_data[8];//DM8009P发送数组

uint8_t Data_Enable[8]={0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFC};		//DM8009P电机使能命令
uint8_t Data_Failure[8]={0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFD};		//DM8009P电机失能命令
uint8_t Data_Save_zero[8]={0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFE};	//DM8009P电机保存零点命令

/**
  * @brief          hal CAN fifo call back, receive motor data
  * @param[in]      hcan, the point to CAN handle
  * @retval         none
  */
/**
  * @brief          hal库CAN回调函数,接收电机数据
  * @param[in]      hcan:CAN句柄指针
  * @retval         none
  */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8];

    HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data);

    switch (rx_header.StdId)
    {
        case CAN_3508_M1_ID:
        case CAN_3508_M2_ID:
        case CAN_3508_M3_ID:
        case CAN_3508_M4_ID:
        case CAN_YAW_MOTOR_ID:
        case CAN_PIT_MOTOR_ID:
        case CAN_TRIGGER_MOTOR_ID:
        {
            static uint8_t i = 0;
            //get motor id
            i = rx_header.StdId - CAN_3508_M1_ID;
            get_motor_measure(&motor_chassis[i], rx_data);
//            detect_hook(CHASSIS_MOTOR1_TOE + i);
            break;
        }
        case CAN_LK9025_LEFT_MOTOR_ID://LK9025 LEFT motor ID
        {
            get_LK9025_motor_measure(&motor_LK9025[0], rx_data);//LK9025 LEFT motor data
            break;
        }
        case CAN_LK9025_RIGHT_MOTOR_ID://LK9025 RIGHT motor ID
        {
            get_LK9025_motor_measure(&motor_LK9025[1], rx_data);//LK9025 RIGHT motor data
            break;
        }
        case CAN_DM8009P_M1_MASTER_ID://DM8009P motor1 ID
        case CAN_DM8009P_M2_MASTER_ID://DM8009P motor2 ID
        case CAN_DM8009P_M3_MASTER_ID://DM8009P motor3 ID
        case CAN_DM8009P_M4_MASTER_ID://DM8009P motor4 ID
        {
            static uint8_t d = 0;
            //get motor id
            d = rx_header.StdId - CAN_DM8009P_M1_ID;
            get_DM8009P_motor_measure(&motor_DM8009P[d], rx_data);//DM8009P motor data
            break;
        }
        default:
        {
            break;
        }
    }
}

/**
 * @brief  采用浮点数据等比例转换成整数
 * @param  x_int     	要转换的无符号整数
 * @param  x_min      目标浮点数的最小值
 * @param  x_max    	目标浮点数的最大值
 * @param  bits      	无符号整数的位数
 */
float uint_to_float(int x_int, float x_min, float x_max, int bits){
  /// converts unsigned int to float, given range and number of bits ///
   float span = x_max - x_min;
   float offset = x_min;
   return ((float)x_int)*span/((float)((1<<bits)-1)) + offset;
  }
  
  /**
   * @brief  将浮点数转换为无符号整数
   * @param  x     			要转换的浮点数
   * @param  x_min      浮点数的最小值
   * @param  x_max    	浮点数的最大值
   * @param  bits      	无符号整数的位数
   */
  
  int float_to_uint(float x, float x_min, float x_max, int bits){
   /// Converts a float to an unsigned int, given range and number of bits///
   float span = x_max - x_min;
   float offset = x_min;
   return (int) ((x-offset)*((float)((1<<bits)-1))/span);
  }

  /**
 * @brief  发送标准ID的数据帧
 * @param  hcan     CAN的句柄
 * @param  ID       数据帧ID
 * @param  pData    数组指针
 * @param  Len      字节数0~8
 */
uint8_t CANx_SendStdData(CAN_HandleTypeDef* hcan,uint16_t ID,uint8_t *pData,uint16_t Len)
{
  
	uint32_t send_mail_box;
	DM8009P_tx_message.StdId=ID;
	DM8009P_tx_message.ExtId=0;
	DM8009P_tx_message.IDE=0;
	DM8009P_tx_message.RTR=0;
	DM8009P_tx_message.DLC=Len;
	
	HAL_CAN_AddTxMessage(hcan, &DM8009P_tx_message, pData, &send_mail_box);
  
    return 0;
}

/**
  * @brief          send control current of motor (0x205, 0x206, 0x207, 0x208)
  * @param[in]      yaw: (0x205) 6020 motor control current, range [-30000,30000] 
  * @param[in]      pitch: (0x206) 6020 motor control current, range [-30000,30000]
  * @param[in]      shoot: (0x207) 2006 motor control current, range [-10000,10000]
  * @param[in]      rev: (0x208) reserve motor control current
  * @retval         none
  */
/**
  * @brief          发送电机控制电流(0x205,0x206,0x207,0x208)
  * @param[in]      yaw: (0x205) 6020电机控制电流, 范围 [-30000,30000]
  * @param[in]      pitch: (0x206) 6020电机控制电流, 范围 [-30000,30000]
  * @param[in]      shoot: (0x207) 2006电机控制电流, 范围 [-10000,10000]
  * @param[in]      rev: (0x208) 保留，电机控制电流
  * @retval         none
  */
void CAN_cmd_gimbal(int16_t yaw, int16_t pitch, int16_t shoot, int16_t rev)
{
    uint32_t send_mail_box;
    gimbal_tx_message.StdId = CAN_GIMBAL_ALL_ID;
    gimbal_tx_message.IDE = CAN_ID_STD;
    gimbal_tx_message.RTR = CAN_RTR_DATA;
    gimbal_tx_message.DLC = 0x08;
    gimbal_can_send_data[0] = (yaw >> 8);
    gimbal_can_send_data[1] = yaw;
    gimbal_can_send_data[2] = (pitch >> 8);
    gimbal_can_send_data[3] = pitch;
    gimbal_can_send_data[4] = (shoot >> 8);
    gimbal_can_send_data[5] = shoot;
    gimbal_can_send_data[6] = (rev >> 8);
    gimbal_can_send_data[7] = rev;
    HAL_CAN_AddTxMessage(&GIMBAL_CAN, &gimbal_tx_message, gimbal_can_send_data, &send_mail_box);
}

/**
  * @brief          send CAN packet of ID 0x700, it will set chassis motor 3508 to quick ID setting
  * @param[in]      none
  * @retval         none
  */
/**
  * @brief          发送ID为0x700的CAN包,它会设置3508电机进入快速设置ID
  * @param[in]      none
  * @retval         none
  */
void CAN_cmd_chassis_reset_ID(void)
{
    uint32_t send_mail_box;
    chassis_tx_message.StdId = 0x700;
    chassis_tx_message.IDE = CAN_ID_STD;
    chassis_tx_message.RTR = CAN_RTR_DATA;
    chassis_tx_message.DLC = 0x08;
    chassis_can_send_data[0] = 0;
    chassis_can_send_data[1] = 0;
    chassis_can_send_data[2] = 0;
    chassis_can_send_data[3] = 0;
    chassis_can_send_data[4] = 0;
    chassis_can_send_data[5] = 0;
    chassis_can_send_data[6] = 0;
    chassis_can_send_data[7] = 0;

    HAL_CAN_AddTxMessage(&CHASSIS_CAN, &chassis_tx_message, chassis_can_send_data, &send_mail_box);
}


/**
  * @brief          send control current of motor (0x201, 0x202, 0x203, 0x204)
  * @param[in]      motor1: (0x201) 3508 motor control current, range [-16384,16384] 
  * @param[in]      motor2: (0x202) 3508 motor control current, range [-16384,16384] 
  * @param[in]      motor3: (0x203) 3508 motor control current, range [-16384,16384] 
  * @param[in]      motor4: (0x204) 3508 motor control current, range [-16384,16384] 
  * @retval         none
  */
/**
  * @brief          发送电机控制电流(0x201,0x202,0x203,0x204)
  * @param[in]      motor1: (0x201) 3508电机控制电流, 范围 [-16384,16384]
  * @param[in]      motor2: (0x202) 3508电机控制电流, 范围 [-16384,16384]
  * @param[in]      motor3: (0x203) 3508电机控制电流, 范围 [-16384,16384]
  * @param[in]      motor4: (0x204) 3508电机控制电流, 范围 [-16384,16384]
  * @retval         none
  */
void CAN_cmd_chassis(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4)
{
    uint32_t send_mail_box;
    chassis_tx_message.StdId = CAN_CHASSIS_ALL_ID;
    chassis_tx_message.IDE = CAN_ID_STD;
    chassis_tx_message.RTR = CAN_RTR_DATA;
    chassis_tx_message.DLC = 0x08;
    chassis_can_send_data[0] = motor1 >> 8;
    chassis_can_send_data[1] = motor1;
    chassis_can_send_data[2] = motor2 >> 8;
    chassis_can_send_data[3] = motor2;
    chassis_can_send_data[4] = motor3 >> 8;
    chassis_can_send_data[5] = motor3;
    chassis_can_send_data[6] = motor4 >> 8;
    chassis_can_send_data[7] = motor4;

    HAL_CAN_AddTxMessage(&CHASSIS_CAN, &chassis_tx_message, chassis_can_send_data, &send_mail_box);
}

/**
  * @brief  增量位置闭环控制命令1 ：主机发送该命令以控制电机的位置增量。
  * @param[in]      angleIncrement:控制值 angleIncrement 为 int32_t 类型，
  *                 对应实际位置为 0.01degree/LSB，即 36000 代表 360°，电机的转动方向由该参数的符号决定。
  * @retval         none
  */
 void CAN_cmd_LK9025(uint16_t CAN_LK9025_MOTOR_ID,uint32_t angleIncrement)
 {
     uint32_t send_mail_box;
     LK9025_tx_message.StdId = CAN_LK9025_MOTOR_ID;//LK9025 ID：0x141
     LK9025_tx_message.IDE = CAN_ID_STD;
     LK9025_tx_message.RTR = CAN_RTR_DATA;
     LK9025_tx_message.DLC = 0x08;
     LK9025_can_send_data[0] = 0xA7;
     LK9025_can_send_data[1] = 0x00;
     LK9025_can_send_data[2] = 0x00;
     LK9025_can_send_data[3] = 0x00;
     LK9025_can_send_data[4] = angleIncrement;      //位置控制低字节 DATA[4] = *(uint8_t *)(& angleIncrement)
     LK9025_can_send_data[5] = angleIncrement >> 8; //位置控制 DATA[5] = *((uint8_t *)(& angleIncrement)+1)
     LK9025_can_send_data[6] = angleIncrement >> 16;//位置控制 DATA[6] = *((uint8_t *)(& angleIncrement)+2)
     LK9025_can_send_data[7] = angleIncrement >> 24;//位置控制高字节 DATA[7] = *((uint8_t *)(& angleIncrement)+3)
 
   /*
   备注：
   1. 该命令下电机的最大速度由上位机中的 Max Speed 值限制。
   2. 该控制模式下，电机的最大加速度由上位机中的 Max Acceleration 值限制。
   3. 该控制模式下，MF、MH、MG 电机的最大转矩电流由上位机中的 Max Torque Current 值限制；
   MS 电机的最大功率由上位机中的 Max Power 值限制。
   */
     HAL_CAN_AddTxMessage(&GIMBAL_CAN, &LK9025_tx_message, LK9025_can_send_data, &send_mail_box);
 }
 
 /**
  * @brief  转矩闭环控制命令 主机发送该命令以控制电机的转矩电流输出。
  * @param[in]      iqControl: 控制值 iqControl 为 int16_t 类型，
  *                 范围 [-2048，2048]，对应电机的转矩电流输出。
  * @retval         none
  */
 void CAN_cmd_Torque_LK9025(uint16_t CAN_LK9025_MOTOR_ID, int16_t iqControl)
 {
     uint32_t send_mail_box;
     LK9025_tx_message.StdId = CAN_LK9025_MOTOR_ID;//LK9025 ID：0x156
     LK9025_tx_message.IDE = CAN_ID_STD;
     LK9025_tx_message.RTR = CAN_RTR_DATA;
     LK9025_tx_message.DLC = 0x08;
     LK9025_can_send_data[0] = 0xA1;
     LK9025_can_send_data[1] = 0x00;
     LK9025_can_send_data[2] = 0x00;
     LK9025_can_send_data[3] = 0x00;
     LK9025_can_send_data[4] = iqControl ;//转矩电流控制值低字节 DATA[4] = *(uint8_t *)(&iqControl)
     LK9025_can_send_data[5] = iqControl >> 8;//转矩电流控制值高字节 DATA[5] = *((uint8_t *)(&iqControl)+1)
     LK9025_can_send_data[6] = 0x00;
     LK9025_can_send_data[7] = 0x00;
 
   /*
   备注：
    1. 该命令中的控制值 iqControl 不受上位机中的 Max Torque Current 值限制。
    2. 该命令的控制值范围应在[-2048, 2048]之间。
   */
     HAL_CAN_AddTxMessage(&CHASSIS_CAN, &LK9025_tx_message, LK9025_can_send_data, &send_mail_box);
 }

  /**
  * @brief  速度闭环控制命令 主机发送该命令以控制电机的速度， 同时带有力矩限制。
  * @param[in]      iqControl: 控制值 iqControl 为 int16_t 类型，
  *                 范围 [-2048，2048]，对应电机的转矩电流输出。
  * @param[in]      speed: 控制值 speed 为 int32_t 类型，最大值由上位机中的Max Speed 值限制。
  * @retval         none
  */
 void CAN_cmd_SPEED_LK9025(uint16_t CAN_LK9025_MOTOR_ID,int16_t iqControl, int32_t speed)
 {
     uint32_t send_mail_box;
     LK9025_tx_message.StdId = CAN_LK9025_MOTOR_ID;//LK9025 ID：0x156
     LK9025_tx_message.IDE = CAN_ID_STD;
     LK9025_tx_message.RTR = CAN_RTR_DATA;
     LK9025_tx_message.DLC = 0x08;
     LK9025_can_send_data[0] = 0xA2;
     LK9025_can_send_data[1] = 0x00;
     LK9025_can_send_data[2] = iqControl;//转矩电流控制值低字节 DATA[2] = *(uint8_t *)(&iqControl)
     LK9025_can_send_data[3] = iqControl >> 8;//转矩电流控制值高字节 DATA[3] = *((uint8_t *)(&iqControl)+1)
     LK9025_can_send_data[4] = speed ; // 速度控制值低字节 DATA[4] = *(uint8_t *)(&speed)
     LK9025_can_send_data[5] = (speed >> 8); // 速度控制值 DATA[5] = *((uint8_t *)(&speed)+1)
     LK9025_can_send_data[6] = (speed >> 16); // 速度控制值 DATA[6] = *((uint8_t *)(&speed)+2)
     LK9025_can_send_data[7] = (speed >> 24); // 速度控制值高字节 DATA[7] = *((uint8_t *)(&speed)+3)
 
   /*
   备注：
    1. 该命令下电机的 speedControl 由上位机中的 Max Speed 值限制。
    2. 该控制模式下，电机的最大加速度由上位机中的 Max Acceleration 值限制。
    3. iqControl命令的控制值范围应在[-2048, 2048]之间。
   */
     HAL_CAN_AddTxMessage(&CHASSIS_CAN, &LK9025_tx_message, LK9025_can_send_data, &send_mail_box);
 }

 /**
  * @brief  这里对ID为0x11、0x12、0x13、0x14的4个电机进行依次使能，在对电机进行控制前进行使能
  * @param  void     	
  * @param  vodi      
  * @param  void    	
  * @param  void      	
  */
 void DM8009P_Motor_enable(void)
 {
   #if Motar_mode==0
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Enable,8);	
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Enable,8);
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Enable,8);
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Enable,8);
   HAL_Delay(10);
   #elif Motar_mode==1
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Enable,8);	
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Enable,8);
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Enable,8);
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Enable,8);
   HAL_Delay(10);
   #elif Motar_mode==2
  CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Enable,8);	
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Enable,8);
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Enable,8);
   HAL_Delay(10);          
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Enable,8);
   HAL_Delay(10);
   #endif
 }
 
  /**
  * @brief  这里对ID为0x11、0x12、0x13、0x14的4个电机进行依次失能，在对电机进行控制前进行失能
  * @param  void     	
  * @param  vodi      
  * @param  void    	
  * @param  void      	
  */
 void DM8009P_Motor_disable(void)
 {
   #if Motar_mode==0
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Failure,8);	
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Failure,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Failure,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Failure,8);
   HAL_Delay(10);
   #elif Motar_mode==1
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Failure,8);	
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Failure,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Failure,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Failure,8);
   HAL_Delay(10);
   #elif Motar_mode==2
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Failure,8);	
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Failure,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Failure,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Failure,8);
   HAL_Delay(10);
   #endif
 }

 /**
  * @brief  这里对ID为0x11、0x12、0x13、0x14的4个电机进行依次保存零点，在对电机进行控制前进行保存零点
  * @param  void     	
  * @param  vodi      
  * @param  void    	
  * @param  void      	
  */
 void DM8009P_Motor_Save_zero(void)
 {
   #if Motar_mode==0
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Save_zero,8);	
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Save_zero,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Save_zero,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Save_zero,8);
   HAL_Delay(10);
   #elif Motar_mode==1
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Save_zero,8);	
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Save_zero,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Save_zero,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Save_zero,8);
   HAL_Delay(10);
   #elif Motar_mode==2
   CANx_SendStdData(&hcan1,CAN_DM8009P_M1_ID,Data_Save_zero,8);	
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M2_ID,Data_Save_zero,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M3_ID,Data_Save_zero,8);
   HAL_Delay(10);
   CANx_SendStdData(&hcan1,CAN_DM8009P_M4_ID,Data_Save_zero,8);
   HAL_Delay(10);
   #endif
 }

 /**
  * @brief  MIT模式控下控制帧
  * @param  ID     数据帧的ID
  * @param  _pos   位置给定
  * @param  _vel   速度给定
  * @param  _KP    位置比例系数
  * @param  _KD    位置微分系数
  * @param  _torq  转矩给定值
  */
 void CAN_cmd_DM8009P_MIT_CtrlMotor(uint16_t id, float _pos, float _vel,
   float _KP, float _KD, float _torq)
 {
     uint32_t send_mail_box; 
     uint16_t pos_tmp,vel_tmp,kp_tmp,kd_tmp,tor_tmp;
     pos_tmp = float_to_uint(_pos, P_MIN, P_MAX, 16);
     vel_tmp = float_to_uint(_vel, V_MIN, V_MAX, 12);
     kp_tmp = float_to_uint(_KP, KP_MIN, KP_MAX, 12);
     kd_tmp = float_to_uint(_KD, KD_MIN, KD_MAX, 12);
     tor_tmp = float_to_uint(_torq, T_MIN, T_MAX, 12);
   
     DM8009P_tx_message.StdId=id;
     DM8009P_tx_message.IDE=CAN_ID_STD;
     DM8009P_tx_message.RTR=CAN_RTR_DATA;
     DM8009P_tx_message.DLC=0x08;
     
     DM8009P_can_send_data[0] = (pos_tmp >> 8);
     DM8009P_can_send_data[1] = pos_tmp;
     DM8009P_can_send_data[2] = (vel_tmp >> 4);
     DM8009P_can_send_data[3] = ((vel_tmp&0xF)<<4)|(kp_tmp>>8);
     DM8009P_can_send_data[4] = kp_tmp;
     DM8009P_can_send_data[5] = (kd_tmp >> 4);
     DM8009P_can_send_data[6] = ((kd_tmp&0xF)<<4)|(tor_tmp>>8);
     DM8009P_can_send_data[7] = tor_tmp;
     
     HAL_CAN_AddTxMessage(&CHASSIS_CAN, &DM8009P_tx_message, DM8009P_can_send_data, &send_mail_box);
 }

  /**
  * @brief  位置速度模式控下控制帧
  * @param  ID     数据帧的ID
  * @param  _pos   位置给定
  * @param  _vel   速度给定
  * @param  _KP    位置比例系数
  * @param  _KD    位置微分系数
  * @param  _torq  转矩给定值
  */
 void CAN_cmd_DM8009P_POSISTION_CtrlMotor(uint16_t id, float _pos, float _vel)
 {
     uint32_t send_mail_box; 
     uint8_t *pbuf,*vbuf;
	 pbuf=(uint8_t*)&_pos;
	 vbuf=(uint8_t*)&_vel;
	 
     DM8009P_tx_message.StdId=(0x100+id);
     DM8009P_tx_message.IDE=CAN_ID_STD;
     DM8009P_tx_message.RTR=CAN_RTR_DATA;
     DM8009P_tx_message.DLC=0x08;
     
     DM8009P_can_send_data[0] = *pbuf;
	 DM8009P_can_send_data[1] = *(pbuf+1);
	 DM8009P_can_send_data[2] = *(pbuf+2);
	 DM8009P_can_send_data[3] = *(pbuf+3);
	 DM8009P_can_send_data[4] = *vbuf;
	 DM8009P_can_send_data[5] = *(vbuf+1);
	 DM8009P_can_send_data[6] = *(vbuf+2);
	 DM8009P_can_send_data[7] = *(vbuf+3);
     
     HAL_CAN_AddTxMessage(&CHASSIS_CAN, &DM8009P_tx_message, DM8009P_can_send_data, &send_mail_box);
 }
 
/**
  * @brief          return the yaw 6020 motor data point
  * @param[in]      none
  * @retval         motor data point
  */
/**
  * @brief          返回yaw 6020电机数据指针
  * @param[in]      none
  * @retval         电机数据指针
  */
const motor_measure_t *get_yaw_gimbal_motor_measure_point(void)
{
    return &motor_chassis[4];
}

/**
  * @brief          return the pitch 6020 motor data point
  * @param[in]      none
  * @retval         motor data point
  */
/**
  * @brief          返回pitch 6020电机数据指针
  * @param[in]      none
  * @retval         电机数据指针
  */
const motor_measure_t *get_pitch_gimbal_motor_measure_point(void)
{
    return &motor_chassis[5];
}


/**
  * @brief          return the trigger 2006 motor data point
  * @param[in]      none
  * @retval         motor data point
  */
/**
  * @brief          返回拨弹电机 2006电机数据指针
  * @param[in]      none
  * @retval         电机数据指针
  */
const motor_measure_t *get_trigger_motor_measure_point(void)
{
    return &motor_chassis[6];
}


/**
  * @brief          return the chassis 3508 motor data point
  * @param[in]      i: motor number,range [0,3]
  * @retval         motor data point
  */
/**
  * @brief          返回底盘电机 3508电机数据指针
  * @param[in]      i: 电机编号,范围[0,3]
  * @retval         电机数据指针
  */
const motor_measure_t *get_chassis_motor_measure_point(uint8_t i)
{
    return &motor_chassis[(i & 0x03)];
}

/**
  * @brief          返回LK9025电机数据指针
  * @param[in]      i: 电机编号,范围[0,3]
  * @retval         LK9025电机数据指针
  */
 const LK9025_motor_measure_t *get_LK9025_motor_measure_point(uint8_t i)
 {
     return &motor_LK9025[i & 0x03];
 }
 
 /**
   * @brief          返回DM8009P电机数据指针
   * @param[in]      i: 电机编号,范围[0,3]
   * @retval         DM8009P电机数据指针
   */
 const DM8009P_motor_measure_t *get_DM8009P_motor_measure_point(uint8_t i)
 {
      return &motor_DM8009P[(i & 0x03)];
 }

 

