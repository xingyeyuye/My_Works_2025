#include "ShootTask05.h"
#include "cmsis_os.h"
#include "main.h"

#define shoot_laser_on()    laser_on()      //���⿪���궨��
#define shoot_laser_off()   laser_off()     //����رպ궨��

int a=0;
const RC_ctrl_t *shoot_rc_ctrl;
/**
  * @brief          Drone control 
  * @param[in]      argument: NULL
  * @retval         none
  */
/**
  * @brief          Drone control
  * @param[in]      argument: NULL
  * @retval         none
  */
void ShootTask05(void const * argument)
{
	
	Shoot_Motor_Init();
	shoot_rc_ctrl=get_remote_control_point();
	a=20;
    while(1)
    {	a=40;
		Shoot_Condition_Init();
		if(shoot_rc_ctrl->rc.s[1] == 1){
			a=60;
			shoot_laser_on();
			Shoot_Value_Control_SET(2000);
		}
		else{
			Shoot_Value_Control_SET(1000);
			shoot_laser_off();
		}
		
		osDelay(500);

    }
}

void Shoot_Motor_Init(void)
{
	HAL_TIM_Base_Start(&htim1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
	
	Shoot_Value_Control_SET(2000);
	osDelay(1000);
	Shoot_Value_Control_SET(1000);

}

void Shoot_Condition_Init(void){	
	
}

void Shoot_Value_Control_SET(int value){	
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, value);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, value);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, value);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4, value);
}

