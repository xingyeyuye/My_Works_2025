#ifndef CHASSIS_TASK_H
#define CHASSIS_TASK_H

#include "remote_control.h"

//����ǰ�����ҿ��ư���
#define CHASSIS_FRONT_KEY KEY_PRESSED_OFFSET_W
#define CHASSIS_BACK_KEY KEY_PRESSED_OFFSET_S
#define CHASSIS_LEFT_KEY KEY_PRESSED_OFFSET_A
#define CHASSIS_RIGHT_KEY KEY_PRESSED_OFFSET_D

#define Motor_SPEED_PID_KP 10.0f
#define Motor_SPEED_PID_KI 0.00f
#define Motor_SPEED_PID_KD 1.5f
#define Motor_SPEED_PID_OUT_MAX 16000
#define Motor_SPEED_PIF_IOUT_MAX 1000

extern void Chassis_task(void const *pvParameters);


#endif
