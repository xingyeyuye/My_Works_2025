#ifndef SHOOT_TASK_H
#define SHOOT_TASK_H

#include "struct_typedef.h"
#include "remote_control.h" //ң����
#include "bsp_can.h"
#include "CAN_receive.h" //CANͨ��
#include "tim.h"
#include "ist8310driver.h" //������
#include "BMI088driver.h"  //IMU����
#include "math.h"
#include "pid.h"
#include "MahonyAHRS.h" // ������Ԫ���ͽǶ�
#include "usart.h"
#include "bsp_laser.h"
#include "bsp_imu_pwm.h"




/**
  * @brief          DRONE control 
  * @param[in]      argument: NULL
  * @retval         none
  */
/**
  * @brief          ���˻��������
  * @param[in]      argument: NULL
  * @retval         none
  */

extern void ShootTask05(void const * argument);

extern void Shoot_Motor_Init(void);

extern void Shoot_Condition_Init(void);

extern void Shoot_Value_Control_SET(int value);
	
#endif



