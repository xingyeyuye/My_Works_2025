#include "Uart1_task.h"

#include "chassis_task.h"
#include "gimbal_task.h"

#include "dma.h"
#include "usart.h"
#include "bsp_usart.h"
#include <stdio.h>
#include <stdarg.h>
#include "string.h"
#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"

void usart_printf(const char *fmt,...)
{
    static uint8_t tx_buf[256] = {0};
    static va_list ap;
    static uint16_t len;
    va_start(ap, fmt);

    //return length of string 
    
    len = vsprintf((char *)tx_buf, fmt, ap);

    va_end(ap);

    HAL_UART_Transmit_DMA(&huart1,tx_buf, len);

}


void UART1_task(void const *pvParameters)
{

	
//	HAL_UART_Receive_DMA(&huart1,receive_buff,3);
//	__HAL_UART_ENABLE_IT(&huart1,UART_IT_IDLE);
	while(1)
	{
		
//		HAL_UART_Transmit_DMA(&huart1,pid_buff, 5);	
        usart_printf("%d,%d,%d\r\n",target1,actual1,out1);
//		usart_printf("%d,%d,%d\r\n",target2,actual2,out2);
//		usart_printf("%d,%d,%d,%d,%d,%d\r\n",target1,actual1,out1,target2,actual2,out2);
		

  osDelay(10);
	}	
}



//usart_printf(
//"**********\r\n\
//ch0:%d\r\n\
//ch1:%d\r\n\
//ch2:%d\r\n\
//ch3:%d\r\n\
//ch4:%d\r\n\
//s1:%d\r\n\
//s2:%d\r\n\
//mouse_x:%d\r\n\
//mouse_y:%d\r\n\
//press_l:%d\r\n\
//press_r:%d\r\n\
//key:%d\r\n\
//**********\r\n",
//            local_rc_ctrl->rc.ch[0], local_rc_ctrl->rc.ch[1], local_rc_ctrl->rc.ch[2], local_rc_ctrl->rc.ch[3], local_rc_ctrl->rc.ch[4],
//            local_rc_ctrl->rc.s[0], local_rc_ctrl->rc.s[1],
//            local_rc_ctrl->mouse.x, local_rc_ctrl->mouse.y,local_rc_ctrl->mouse.z, local_rc_ctrl->mouse.press_l, local_rc_ctrl->mouse.press_r,
//            local_rc_ctrl->key.v);

