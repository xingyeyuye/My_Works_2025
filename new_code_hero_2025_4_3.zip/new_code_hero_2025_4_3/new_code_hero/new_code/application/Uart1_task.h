#ifndef UART1_TASK_H
#define UART1_TASK_H


extern void UART1_task(void const *pvParameters);


#endif
