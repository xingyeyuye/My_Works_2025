#include "chassis_task.h"

#include "pid.h"
#include "struct_typedef.h"
#include "gimbal_task.h"
#include "CAN_receive.h"
#include "remote_control.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"



const RC_ctrl_t *local_rc_ctrl;
const fp32 motor_speed_pid_constants[3]={Motor_SPEED_PID_KP,Motor_SPEED_PID_KI,Motor_SPEED_PID_KD};
const motor_measure_t *motor_3508[4];

fp32 vx_set;
fp32 vy_set;
fp32 wz_set=0.0f;
fp32 wheel_speed[4]={0};
fp32 chassic_wz_set_scale = 1.0f;
uint8_t i=0;
pid_type_def motor_speed_pid[4]; 
pid_type_def motor01_speed_pid;
/**
 * @brief 底盘初始化
 * @param  空
 */
void chassic_init(void);

void Chassis_task(void const *pvParameters)
{
	//底盘初始化
	chassic_init();
//	PID_init(&motor01_speed_pid, PID_POSITION, motor_speed_pid_constants, 16384, 16384);
	//获取遥控器数据指针
	local_rc_ctrl = get_remote_control_point();

//	motor01_speed_pid.Kp=1500.0f;
	

	while(1)
	{
		
		vx_set = local_rc_ctrl->rc.ch[1]*20.f;
		vy_set = local_rc_ctrl->rc.ch[0]*20.f;
		
		
		//keyboard set speed set-point
    //键盘控制
    if (local_rc_ctrl->key.v & CHASSIS_FRONT_KEY)
    {
        vx_set = 6000;
    }
    else if (local_rc_ctrl->key.v & CHASSIS_BACK_KEY)
    {
        vx_set = -6000;
    }

    if (local_rc_ctrl->key.v & CHASSIS_LEFT_KEY)
    {
        vy_set = 6000;
    }
    else if (local_rc_ctrl->key.v & CHASSIS_RIGHT_KEY)
    {
        vy_set = -6000;
    }
		


 
		if(local_rc_ctrl->rc.s[0]==3)
		{
			wz_set=relative_wz;
//				//全向轮运动解析
//			/* 理论推导教程：https://www.bilibili.com/video/BV1toH6ekEfJ/?share_source=copy_web&vd_source=d3a1fba6fbac273bfbf914fe4deb0660 */
			wheel_speed[0] = (vx_set*0.7071067f-vy_set*0.7071067f+1.1f*wz_set);
			wheel_speed[3] = (vx_set*0.7071067f+vy_set*0.7071067f+1.1f*wz_set);
			wheel_speed[2] = (-vx_set*0.7071067f+vy_set*0.7071067f+1.1f*wz_set);
			wheel_speed[1] = (-vx_set*0.7071067f-vy_set*0.7071067f+1.1f*wz_set);
			
//				 //麦轮运动解析
//			wheel_speed[0] = -vx_set+vy_set+1.9f*wz_set;
//			wheel_speed[1] = vx_set+vy_set+1.9f*wz_set;
//			wheel_speed[2] = vx_set-vy_set+(1.9f)*wz_set;
//			wheel_speed[3] = -vx_set-vy_set+(1.9f)*wz_set;
				//计算PID,获取底盘电机速度
			for (int i = 0; i < 4; i++)
			{
				PID_calc(&motor_speed_pid[i], motor_3508[i]->speed_rpm, wheel_speed[i]);
			}
		
			CAN_cmd_chassis(motor_speed_pid[0].out,motor_speed_pid[1].out,motor_speed_pid[2].out,motor_speed_pid[3].out);
			
		}
		else if(local_rc_ctrl->rc.s[0]==1)
		{
				//全向轮运动解析
			/* 理论推导教程：https://www.bilibili.com/video/BV1toH6ekEfJ/?share_source=copy_web&vd_source=d3a1fba6fbac273bfbf914fe4deb0660 */
			wheel_speed[0] = (0.9f*3000);
			wheel_speed[1] = (0.9f*3000);
			wheel_speed[2] = (0.9f*3000);
			wheel_speed[3] = (0.9f*3000);
				
				//计算PID,获取底盘电机速度
			for (int i = 0; i < 4; i++)
			{
				PID_calc(&motor_speed_pid[i], motor_3508[i]->speed_rpm, wheel_speed[i]);
			}
		
			CAN_cmd_chassis(motor_speed_pid[0].out,motor_speed_pid[1].out,motor_speed_pid[2].out,motor_speed_pid[3].out);
		}
		else
		{
			PID_clear(&motor_speed_pid[0]);
			PID_clear(&motor_speed_pid[1]);
			PID_clear(&motor_speed_pid[2]);
			PID_clear(&motor_speed_pid[3]);
			CAN_cmd_chassis(0,0,0,0);
		}
		
		osDelay(10); 
	}
}


/**
 * @brief 底盘初始化
 * @param  空
 */
void chassic_init(void)
{
	//获取底盘电机数据指针，初始化PID
	for ( i = 0; i < 4; i++)
	{
		
		motor_3508[i] = get_chassis_motor_measure_point(i);
		PID_init(&motor_speed_pid[i], PID_POSITION, motor_speed_pid_constants, 16384, 16384);
	}
}


