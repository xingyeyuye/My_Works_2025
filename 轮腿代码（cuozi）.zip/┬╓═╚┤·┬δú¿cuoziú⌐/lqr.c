#include "lqr.h"
lqr_t lqr;
//float p[48] = {111.24748, 22.03405, -65.17140, -2.67450, -243.01656, 125.29999, -28.95285, 0.29086, -53.84000, 27.97966, -4.70507, -1.25764, -201.59261, 93.54770, -12.58596, -4.85402, 1086.80025, -337.89701, -100.74119, 48.19867, 456.94441, -212.43268, 21.51267, 3.88765, -654.43377, 236.70469, -12.64831, 6.72429, -15.35722, -2.62477, -0.01335, 0.90410, 8.33769, -5.55545, -1.15912, 0.70346, 14.51134, -6.22254, -7.76153, 2.77503, -315.49909, -121.16104, 143.39784, 33.26580, -382.77722, 166.94944, -11.35575, 2.70397};


//float p[48] = {-660.40821, 421.24699, -119.11884, -5.30528, -276.35903, 133.09538, -25.91930, -0.49863, -58.03174, 28.81273, -4.05266, -1.41509, -203.98229, 94.61017, -11.69210, -4.92471, -979.43165, 512.30933, -96.34342, 10.42763, 3.97241, 0.63636, -1.43370, 0.51596, -250.08815, 116.05943, -17.14656, 1.91931, -39.26464, 19.37151, -3.22061, 0.31184, -27.26752, 13.76488, -2.53032, 0.26004, -91.71375, 46.84273, -8.71455, 0.88753, 22.77820, -13.54182, 3.51796, 43.44018, -2.29531, 0.91482, 0.00395, 1.08782};
//nengyongfloat p[48] = {-663.39515, 435.92899, -126.94156, -3.41495, -271.69565, 131.80516, -26.08821, -0.42403, -57.58314, 28.52669, -3.98113, -1.42410, -209.47624, 99.32202, -13.06181, -4.76306, -967.07833, 501.83084, -93.13028, 10.02749, 4.41948, 0.14917, -1.27045, 0.49660, -228.44954, 102.88977, -14.07752, 1.58318, -38.84736, 19.07135, -3.13739, 0.30138, -27.60581, 13.98595, -2.57490, 0.26193, -91.28113, 46.60290, -8.64371, 0.87428, 19.19480, -11.19867, 2.96254, 43.49153, -2.41406, 0.99920, -0.01760, 1.08991};	
	//float p[48] = {-253.19472, 226.20833, -99.99351, -1.43287, -264.93189, 134.65860, -29.28299, 0.14413, -61.86707, 30.71358, -4.54077, -1.34712, -236.23373, 112.60579, -15.63534, -4.59326, 284.53320, -54.58358, -49.69718, 20.20193, 202.01563, -93.19064, 9.77302, 1.64045, -522.33911, 183.26285, -7.62345, 3.89094, -53.24244, 20.61322, -3.35820, 0.76371, -30.65663, 12.91689, -2.79797, 0.55059, -106.48094, 47.94511, -10.91697, 1.99218, -16.91007, -60.50996, 42.90588, 19.79311, -97.79065, 43.66188, -3.29565, 1.36047};
float p[48] = {240.13176, -92.88401, -43.82791, -3.15852, -321.95875, 227.11285, -61.82292, 3.28537, -56.18636, 38.34589, -8.29493, -1.02886, -254.68470, 173.20309, -37.65189, -2.92226, 1666.88560, -1091.97267, 203.06142, 3.37247, 481.74971, -321.63029, 64.91110, -0.59571, -761.51368, 455.65455, -70.02816, 8.21006, -70.27289, 38.87630, -7.07910, 0.69069, -25.21415, 15.26395, -3.41612, 0.29606, -71.80261, 42.31580, -9.54565, 0.74706, -458.35376, 290.37034, -43.21610, 16.61289, -168.72430, 112.85359, -21.55510, 3.81608};

//float p[48] = {-349.24636, 274.06808, -109.94082, -1.53918, -289.80943, 145.97916, -31.44857, 0.12492, -131.94283, 63.77419, -8.78879, -3.14545, -297.45696, 134.92040, -16.78917, -5.64204, 673.97578, -258.58263, -8.69378, 16.15955, 232.66094, -107.13964, 11.65640, 1.63704, -479.05577, 154.49642, 0.45211, 3.20408, -44.08354, 14.68967, -1.80776, 0.62716, -26.57963, -0.64451, 1.35585, 0.50209, -52.57195, 8.48486, -1.07477, 1.20962, -122.98481, 13.89418, 23.81235, 15.30281, -99.28104, 46.81597, -4.58855, 1.28603};
float L0[4];
float k[12];
float k_cal[12];
float k_copy[12];
float k_para[12] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
float torque[2]; //[�������������/�Źؽ��������]
float jacobi_left[4];
float inv_jacobi_left[4];
float jacobi_right[4];
float inv_jacobi_right[4];
// û��ʱ���LQR ״̬�������� Ҳ�������ǲ���ĳ��ȵ� ��ʹ��
float k_noleg[12] = {-22.218, -4.647527, -8.20094374, -9.56364, 12.746, 2.5382, 6.3026, 1.56791771, 3.61372, 3.802, 27.3332, 2.831};
arm_matrix_instance_f32 ptr_error;
arm_matrix_instance_f32 ptr_torque;
// �����Ȳ����ȱ�����Ĳ������� ����
arm_matrix_instance_f32 ptr_p;
arm_matrix_instance_f32 ptr_L0;
arm_matrix_instance_f32 ptr_k;
arm_matrix_instance_f32 ptr_k_cal;
arm_matrix_instance_f32 ptr_jacobi_left;
arm_matrix_instance_f32 ptr_inv_jacobi_left;
arm_matrix_instance_f32 ptr_jacobi_right;
arm_matrix_instance_f32 ptr_inv_jacobi_right;
/// @brief �����ʼ�� ��������
/// @param
void matrix_init(void)
{
    ptr_error.numCols = 1;
    ptr_error.numRows = 6;
    ptr_error.pData = lqr.error;

    ptr_torque.numCols = 1;
    ptr_torque.numRows = 2;
    ptr_torque.pData = torque;

    ptr_p.numCols = 4;
    ptr_p.numRows = 12;
    ptr_p.pData = p;

    ptr_L0.numCols = 1;
    ptr_L0.numRows = 4;
    ptr_L0.pData = L0;

    ptr_k.numCols = 1;
    ptr_k.numRows = 12;
    ptr_k.pData = k;

    ptr_k_cal.numCols = 6;
    ptr_k_cal.numRows = 2;
    ptr_k_cal.pData = k_cal;

    ptr_jacobi_left.numCols = 2;
    ptr_jacobi_left.numRows = 2;
    ptr_jacobi_left.pData = jacobi_left;

    ptr_inv_jacobi_left.numCols = 2;
    ptr_inv_jacobi_left.numRows = 2;
    ptr_inv_jacobi_left.pData = inv_jacobi_left;

    ptr_jacobi_right.numCols = 2;
    ptr_jacobi_right.numRows = 2;
    ptr_jacobi_right.pData = jacobi_right;

    ptr_inv_jacobi_right.numCols = 2;
    ptr_inv_jacobi_right.numRows = 2;
    ptr_inv_jacobi_right.pData = inv_jacobi_right;
}

/**
 * @description: �ȳ�����->����״̬�������� 
 * @param {}
 * @return {*}
 */
void match_k(void)
{
    float L;

    L = balance_chassis.L0_avg;

    // �����ȳ����� ����ʽ
    L0[0] = L * L * L;
    L0[1] = L * L;
    L0[2] = L;
    L0[3] = 1;

    // ���㵱ǰ�ȳ��µ�kֵ �������
    arm_mat_mult_f32(&ptr_p, &ptr_L0, &ptr_k);

    for (int i = 0; i <= 11; i++)
    {
        k_cal[i] = k[i];  // �����Сת��
        k_copy[i] = k[i]; // ������
        k_cal[i] *= k_para[i];
    }
}




/**
 * @description: �����ں�
 * @param {dt} ʱ�䲽��
 * @param {acc} ���ٶȲ���ֵ
 * @param {speed} �ٶȲ���ֵ
 * @param {vel_esti} ָ������ٶȵ�ָ��
 * @return {*}
 */
float Rz = 0.3; 
float Qz = 0.003;

void speed_est(const float dt, const float acc, const float speed, float *vel_esti)
{
    static float _x = 0;
    static float _Pz = 1;
    
    float H = 1;
    float A = 1;
    float B = dt;
    float _x_est;
    float _p_est;
    float K;
    
    // Ԥ�ⲽ��
    _x_est = A * _x + B * acc;
    _p_est = _Pz + Qz; // A * _P * A_T + Q
    
    // ���²���
    K = _p_est / (_p_est + Rz);
    _x = _x_est + K * (speed - _x_est);
    _Pz = (1 - K) * _p_est;   
    
    *vel_esti = _x;
}

float kf_fusion;
float forward_acc;
float data_fusion(void)//�ٶ��ںϵ���
{
    float fusion;
    forward_acc = INS_accel[1];
    float speed;
		//�ٶȷ��� �޸�
    speed = (driving_motor[RIGHT].speed - driving_motor[LEFT].speed) / 2.0f;
    speed_est(0.001,forward_acc,speed,&fusion);
    
	  return fusion;
}
/**
 * @description:�ٶȲ�������
 * @param {}
 * @return {*}
 */

float speed_step = 0.002f;
float speed_desire_slow;
void speed_slow(float *recspeed , float target , float slow_Inc)
{

  if(fabs(*recspeed - target) < slow_Inc) *recspeed = target;
  else {
    if((*recspeed) > target) (*recspeed) -= slow_Inc;
    if((*recspeed) < target) (*recspeed) += slow_Inc;
  }
}



/**
 * @description: ����״̬����ֵ
 * @param {}
 * @return {*}
 */
pose_t pose;

float time_get;
float fusion_speed;
float speed;
int error_flag;
int action_flag;
float fusion_abs;
float speed_abs;
float motor_speed;
void matrix_state_assign(void)

{
    speed_slow(&speed_desire_slow,(rc_ctrl.rc.ch[3]/ 440.0f),speed_step);
	  pose.pose = motion_resolve[0].phi0;            // VMC�İڽ�
    pose.Dpose = phi0_dot_cal(&motion_resolve[0]); // VMC�ڽǵĽ��ٶ�
    fusion_speed = -data_fusion()*0.5;//����û����������ں�
		motor_speed = (driving_motor[LEFT].speed - driving_motor[RIGHT].speed) / 2.0f;
	  ///////״̬����ֵ////////
	  if ((fabs(speed_desire_slow) > 0.01) || fabs(fusion_speed) > 0.3)//�ж�ģʽ��λ���л�����
    {

			  lqr.state[DISPLAYCEMENT] = 0;
			  action_flag = 1;
    }
		else
		{
			  
			  lqr.state[DISPLAYCEMENT] += motor_speed * 0.001f; //λ��
			  action_flag = 0;
		}
    lqr.state[SPEED] = fusion_speed; //�ٶ�
		lqr.state[PITCH] = -INS_angle[2]; //�����Ƕ�
		lqr.state[PITCH_SPEED] = -INS_gyro[0];//�������ٶ�
    lqr.state[POSE_ANGLE] = -(1.57 - (pose.pose - lqr.state[PITCH])); //����̬�Ƕ�
    lqr.state[POSE_SPEED] =  1* (pose.Dpose - lqr.state[PITCH_SPEED]);//����̬���ٶ�
    /////////// ///////////////
		fusion_abs = fabs(lqr.state[SPEED]);//�ٶ��ںϵľ���ֵ
		speed_abs = fabs((driving_motor[RIGHT].speed - driving_motor[LEFT].speed) / 2.0f);//���پ���ֵ
}

/**
 * @description: ����������ֵ
 * @param {}
 * @return {*}
 */
//ƽ�����
float balance_angle = -0.000f;
float theta_angle = 0.00f;
float disp_para = 0.0001f;
void matrix_desire_assign(void)
{
    lqr.desire[PITCH] = -rc_ctrl.rc.ch[1]/ 990.0f;//����Ϊ0
    lqr.desire[PITCH_SPEED] = 0.0f;//Ϊ0
    lqr.desire[SPEED] = balance_chassis.chassis_status.chassis_desire.speed + speed_desire_slow;//LINK RC
    lqr.desire[POSE_ANGLE] = 0.0f;
		lqr.desire[POSE_SPEED] = 0.0f;//����Ϊ0
    lqr.desire[DISPLAYCEMENT] = 0;//Action Mode
}
/**
 * @description: ������������β�������ϵ��
 * @param {}
 * @return {*}
 */
void matrix_error_calculate(void)
{
    matrix_state_assign();
    matrix_desire_assign();
    match_k();
    if(fly_flag == 0)//�˶�״̬����
		{
	  lqr.error[POSE_ANGLE] = lqr.desire[POSE_ANGLE] - lqr.state[POSE_ANGLE];
    lqr.error[POSE_SPEED] = lqr.desire[POSE_SPEED] - lqr.state[POSE_SPEED];
	  lqr.error[DISPLAYCEMENT] = lqr.desire[DISPLAYCEMENT] - lqr.state[DISPLAYCEMENT];
	  lqr.error[SPEED] = lqr.desire[SPEED] - lqr.state[SPEED];
	  lqr.error[PITCH] = lqr.desire[PITCH] - lqr.state[PITCH];
	  lqr.error[PITCH_SPEED] = lqr.desire[PITCH_SPEED] - lqr.state[PITCH_SPEED];
		}
		else//���״̬����
		{
		lqr.error[POSE_ANGLE] = lqr.desire[POSE_ANGLE] - lqr.state[POSE_ANGLE];
    lqr.error[POSE_SPEED] = lqr.desire[POSE_SPEED] - lqr.state[POSE_SPEED];
	  lqr.error[DISPLAYCEMENT] = 0;
	  lqr.error[SPEED] = 0;
	  lqr.error[PITCH] = 0;
	  lqr.error[PITCH_SPEED] = 0;
		}
}

/**
 * @description: ��������
 * @param {}
 * @return {��־λ}
 */
int matrix_judge;
int matrix_calculate(void)
{
    matrix_error_calculate();
    arm_mat_mult_f32(&ptr_k_cal, &ptr_error, &ptr_torque);
    lqr.pos_out[DRIVING] = torque[DRIVING];
    lqr.pos_out[JOINT] = torque[JOINT];
    return matrix_judge;
}
